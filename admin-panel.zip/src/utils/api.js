const apiUrl = "https://api.buxgalterpro.uz/api"

export default apiUrl;