import LoginMain from "@/components/login/LoginMain";
import React from "react";

const LoginPage = () => {
  return (
    <>
      <LoginMain />
    </>
  );
};

export default LoginPage;
