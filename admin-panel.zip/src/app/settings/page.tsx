import AddCategorySubCategoryMain from "@/components/settings/AddCategroyAndSubCategory/AddCategorySubCategoryMain";
import React from "react";

const AddCategroyandSubCategoryPage = () => {
  return (
    <>
      <AddCategorySubCategoryMain />
    </>
  );
};

export default AddCategroyandSubCategoryPage;
