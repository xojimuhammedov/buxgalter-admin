//@refresh

import HomePageMain from "@/components/home-page/HomePageMain";

const HomePage = () => {
  return (
    <>
      <HomePageMain />
    </>
  );
};

export default HomePage;
