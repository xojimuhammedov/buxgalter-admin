import RegistarMain from "@/components/register/RegistarMain";

const SignUp = () => {
  return (
    <>
      <RegistarMain />
    </>
  );
};

export default SignUp;
