import React from 'react';
import BlogList from './BlogList';

const BlogMain = () => {
    return (
        <>
            <BlogList/>
        </>
    );
};

export default BlogMain;