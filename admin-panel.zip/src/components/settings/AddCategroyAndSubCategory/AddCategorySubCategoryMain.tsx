import ContentWrapper from '@/layout/sidebar/ContentWrapper';
import React from 'react';
import Content from './Content';

const AddCategorySubCategoryMain = () => {
    return (
        <>
          <ContentWrapper breadCampTitle="Settings">
              <Content/>
            </ContentWrapper>  
        </>
    );
};

export default AddCategorySubCategoryMain;