import React from "react";

const CopyRigth = () => {
  return (
    <>
      <div className="cashier-copyright-area">
        {/* <div className="cashier-copyright text-center bg-themeBlue h-20 leading-[80px] mt-20">
          <span className="text-[15px] text-white font-normal">
            © Copyright by <a target='_blank' href="https://centurysilkroadtravel.uz">centurysilkroadtravel.uz</a> 2023-2024
          </span>
        </div> */}
      </div>
    </>
  );
};

export default CopyRigth;
