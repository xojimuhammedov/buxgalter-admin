import React from 'react';
import ProfileContent from './ProfileContent';

const ProfileMain = () => {
    return (
        <>
           <ProfileContent/> 
        </>
    );
};

export default ProfileMain;