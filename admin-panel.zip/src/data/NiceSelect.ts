export const GenderData = [
    {
        id:1,
        categoryName:"Male"
    },
    {
        id:2,
        categoryName:"Female"
    }
]